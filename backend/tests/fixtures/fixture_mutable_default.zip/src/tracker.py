def record_event(name: str, tags: list[str] = []) -> list[str]:
    tags.append(name)
    return tags
