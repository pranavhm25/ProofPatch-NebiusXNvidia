import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.tracker import record_event


def test_first_call():
    assert record_event("login") == ["login"]


def test_second_call_isolated():
    assert record_event("logout") == ["logout"]


def test_explicit_list():
    assert record_event("custom", ["init"]) == ["init", "custom"]
