def calculate_discounted_price(price: float, discount_percent: float) -> float:
    """Calculate the final price after applying discount percentage."""
    # Defect: wrong operator adds discount instead of subtracting (+ instead of -)
    return price + (price * (discount_percent / 100.0))
