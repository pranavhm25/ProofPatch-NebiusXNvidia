import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.discount import calculate_discounted_price


def test_standard_discount():
    assert calculate_discounted_price(100.0, 20.0) == 80.0


def test_zero_discount():
    assert calculate_discounted_price(50.0, 0.0) == 50.0


def test_full_discount():
    assert calculate_discounted_price(75.0, 100.0) == 0.0
