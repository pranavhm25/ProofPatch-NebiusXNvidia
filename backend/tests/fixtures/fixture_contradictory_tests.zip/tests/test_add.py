import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.math_ops import add


def test_add_four():
    assert add(2, 2) == 4


def test_add_five():
    assert add(2, 2) == 5
