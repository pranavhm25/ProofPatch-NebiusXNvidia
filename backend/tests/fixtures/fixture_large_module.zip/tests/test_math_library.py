import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.math_library import add, mean, median, clamp, is_prime


def test_add():
    assert add(2, 3) == 5


def test_clamp():
    assert clamp(15, 0, 10) == 10


def test_mean():
    assert mean([1.0, 2.0, 3.0]) == 2.0


def test_median_odd():
    assert median([5.0, 1.0, 3.0]) == 3.0


def test_median_even():
    assert median([4.0, 1.0, 3.0, 2.0]) == 2.5


def test_prime():
    assert is_prime(7) is True
    assert is_prime(4) is False
