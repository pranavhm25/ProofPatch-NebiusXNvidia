import math
from typing import List, Union

def add(a: float, b: float) -> float:
    return a + b

def subtract(a: float, b: float) -> float:
    return a - b

def multiply(a: float, b: float) -> float:
    return a * b

def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("Division by zero")
    return a / b

def clamp(val: float, low: float, high: float) -> float:
    if val < low:
        return low
    if val > high:
        return high
    return val

def mean(numbers: List[float]) -> float:
    if not numbers:
        raise ValueError("Empty list")
    return sum(numbers) / len(numbers)

def median(numbers: List[float]) -> float:
    if not numbers:
        raise ValueError("Empty list")
    mid = len(numbers) // 2
    if len(numbers) % 2 == 1:
        return numbers[mid]
    return (numbers[mid - 1] + numbers[mid]) / 2.0

def variance(numbers: List[float]) -> float:
    if len(numbers) < 2:
        raise ValueError("Need at least 2 numbers")
    m = mean(numbers)
    return sum((x - m) ** 2 for x in numbers) / (len(numbers) - 1)

def standard_deviation(numbers: List[float]) -> float:
    return math.sqrt(variance(numbers))

def dot_product(v1: List[float], v2: List[float]) -> float:
    if len(v1) != len(v2):
        raise ValueError("Vectors must have equal length")
    return sum(a * b for a, b in zip(v1, v2))

def vector_magnitude(v: List[float]) -> float:
    return math.sqrt(sum(x ** 2 for x in v))

def normalize_vector(v: List[float]) -> List[float]:
    mag = vector_magnitude(v)
    if mag == 0:
        raise ValueError("Cannot normalize zero vector")
    return [x / mag for x in v]

def linear_interpolate(start: float, end: float, t: float) -> float:
    return start + t * (end - start)

def is_prime(n: int) -> bool:
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True
