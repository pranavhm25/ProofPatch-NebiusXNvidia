import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.service import get_service_status


def test_service_status():
    assert get_service_status() == "operational"
