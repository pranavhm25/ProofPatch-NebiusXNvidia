def allocate_large():
    return bytearray(1024 * 1024 * 1024)
