import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from src.mem import allocate_large

def test_allocate_memory_hog():
    data = allocate_large()
    assert len(data) > 0
