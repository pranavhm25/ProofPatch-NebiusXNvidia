import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.parser import parse_int_safely


def test_valid_integer():
    assert parse_int_safely("42") == 42


def test_invalid_string():
    assert parse_int_safely("not_a_number", default=-1) == -1


def test_none_value():
    assert parse_int_safely(None, default=0) == 0
