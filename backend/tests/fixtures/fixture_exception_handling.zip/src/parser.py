def parse_int_safely(val: str, default: int = 0) -> int:
    try:
        return int(val)
    except TypeError:
        return default
