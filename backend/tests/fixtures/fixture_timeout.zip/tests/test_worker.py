import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.worker import perform_task


def test_hanging_execution():
    time.sleep(300)
    assert perform_task() is True
