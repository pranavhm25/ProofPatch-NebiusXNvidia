def perform_task():
    return True
