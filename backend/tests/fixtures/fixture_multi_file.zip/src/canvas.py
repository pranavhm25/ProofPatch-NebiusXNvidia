from src.models import Rect

def calculate_total_border_length(shapes: list[Rect]) -> float:
    return sum(shape.area() for shape in shapes)
