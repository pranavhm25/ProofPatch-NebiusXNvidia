import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models import Rect
from src.canvas import calculate_total_border_length


def test_rect_perimeter():
    r = Rect(3.0, 4.0)
    assert r.perimeter() == 14.0


def test_total_border_length():
    shapes = [Rect(2.0, 3.0), Rect(4.0, 5.0)]
    assert calculate_total_border_length(shapes) == 28.0
