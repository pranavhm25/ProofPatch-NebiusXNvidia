def count_range(numbers: list[int], lower: int, upper: int) -> int:
    """Count how many numbers fall within [lower, upper] inclusive."""
    # Defect: excludes upper bound (off-by-one: < instead of <=)
    return sum(1 for x in numbers if lower <= x < upper)
