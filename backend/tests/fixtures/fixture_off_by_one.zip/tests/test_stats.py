import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.stats import count_range


def test_within_range():
    assert count_range([1, 2, 3, 4, 5], 2, 4) == 3


def test_no_matches():
    assert count_range([10, 20, 30], 1, 5) == 0


def test_all_matches():
    assert count_range([5, 5, 5], 5, 5) == 3
