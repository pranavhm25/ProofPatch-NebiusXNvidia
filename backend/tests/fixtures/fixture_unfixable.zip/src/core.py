def compute():
    return "alpha"
