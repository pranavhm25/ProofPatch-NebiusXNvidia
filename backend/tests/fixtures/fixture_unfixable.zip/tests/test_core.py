import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core import compute


def test_compute_impossible():
    # Requires hash matching an unknown external secret that cannot be deduced
    assert compute() == "impossible-external-token-938210948"
